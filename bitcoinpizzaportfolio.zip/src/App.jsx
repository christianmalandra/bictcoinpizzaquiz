import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Quiz from './components/Quiz'
import FloatingPizzasBackground from './components/FloatingPizzasBackground'
import BtcPizzaIndicator from './components/BtcPizzaIndicator'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <FloatingPizzasBackground />
      <div style={{ position: 'fixed', top: 40, right: 40, zIndex: 1100 }}>
        <BtcPizzaIndicator />
      </div>
      <div className="min-h-screen bg-gray-100">
        <Quiz />
      </div>
    </>
  )
}

export default App
