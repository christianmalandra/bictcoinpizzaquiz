import React from 'react';

const BtcPizzaIndicator = () => {
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '6px',
      minWidth: '120px',
      background: 'rgba(255,255,255,0.85)',
      borderRadius: '2rem',
      boxShadow: '0 4px 24px 0 rgba(255,140,0,0.18)',
      padding: '18px 18px',
      border: '1.5px solid #ffe0b2',
      backdropFilter: 'blur(2px)',
      fontWeight: 'bold',
      color: '#ff9800',
      fontSize: '1.1rem',
      textShadow: '0 1px 4px #fff8e1',
      zIndex: 1001,
    }}>
      <span style={{ fontSize: '1.5rem', marginBottom: '2px' }}>🍕 = ₿ 5,000</span>
      <span style={{ fontSize: '0.95rem', color: '#b26a00', fontWeight: 500 }}>1 Bitcoin Pizza</span>
    </div>
  );
};

export default BtcPizzaIndicator; 