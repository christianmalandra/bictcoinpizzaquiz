import React from 'react';

const floatingStyles = [
  { top: '10%', left: '12%', animation: 'float1 12s ease-in-out infinite', fontSize: '2.8rem', zIndex: 1 },
  { top: '60%', left: '20%', animation: 'float2 14s ease-in-out infinite', fontSize: '3.2rem', zIndex: 2 },
  { top: '30%', left: '70%', animation: 'float3 16s ease-in-out infinite', fontSize: '2.6rem', zIndex: 1 },
  { top: '75%', left: '80%', animation: 'float1 18s ease-in-out infinite', fontSize: '2.2rem', zIndex: 2 },
  { top: '50%', left: '50%', animation: 'float2 20s ease-in-out infinite', fontSize: '3.4rem', zIndex: 1 },
  { top: '20%', left: '80%', animation: 'float3 15s ease-in-out infinite', fontSize: '2.4rem', zIndex: 1 },
  { top: '80%', left: '30%', animation: 'float1 17s ease-in-out infinite', fontSize: '2.7rem', zIndex: 2 },
  { top: '40%', left: '60%', animation: 'float2 13s ease-in-out infinite', fontSize: '2.9rem', zIndex: 1 },
];

export default function FloatingPizzasBackground() {
  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      width: '100vw',
      height: '100vh',
      pointerEvents: 'none',
      zIndex: 0,
      overflow: 'hidden',
    }}>
      {floatingStyles.map((style, i) => (
        <span
          key={i}
          role="img"
          aria-label="pizza"
          style={{
            position: 'absolute',
            ...style,
            opacity: 0.7,
            filter: 'drop-shadow(0 4px 16px rgba(0,0,0,0.10))',
            transition: 'transform 0.3s',
            userSelect: 'none',
            textShadow: '0 2px 8px #fffde7',
          }}
        >
          🍕
        </span>
      ))}
      <style>{`
        @keyframes float1 {
          0% { transform: translateY(0px) scale(1) rotate(-8deg); }
          50% { transform: translateY(-40px) scale(1.08) rotate(8deg); }
          100% { transform: translateY(0px) scale(1) rotate(-8deg); }
        }
        @keyframes float2 {
          0% { transform: translateY(0px) scale(1) rotate(6deg); }
          50% { transform: translateY(30px) scale(1.12) rotate(-6deg); }
          100% { transform: translateY(0px) scale(1) rotate(6deg); }
        }
        @keyframes float3 {
          0% { transform: translateY(0px) scale(1) rotate(0deg); }
          50% { transform: translateY(-25px) scale(1.05) rotate(12deg); }
          100% { transform: translateY(0px) scale(1) rotate(0deg); }
        }
      `}</style>
    </div>
  );
} 