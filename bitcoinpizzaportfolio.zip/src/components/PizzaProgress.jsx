import React from 'react';

const PizzaProgress = ({ score, totalSlices = 8, currentQuestion = 1, totalQuestions = 8 }) => {
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '10px',
      minWidth: '60px',
      background: 'rgba(255,255,255,0.85)',
      borderRadius: '2rem',
      boxShadow: '0 4px 24px 0 rgba(255,140,0,0.18)',
      padding: '18px 12px',
      border: '1.5px solid #ffe0b2',
      backdropFilter: 'blur(2px)'
    }}>
      <div style={{ fontWeight: 'bold', color: '#ff9800', marginBottom: '8px', fontSize: '1.1rem', textShadow: '0 1px 4px #fff8e1' }}>
        Question {currentQuestion}/{totalQuestions}
      </div>
      {Array.from({ length: totalSlices }).map((_, i) => (
        <span
          key={i}
          style={{
            fontSize: '2.2rem',
            opacity: i < score ? 0.2 : 1,
            transition: 'opacity 0.3s',
            filter: i < score ? 'grayscale(1)' : 'none',
            userSelect: 'none',
            display: 'block',
            textShadow: '0 2px 8px #fffde7',
          }}
          role="img"
          aria-label="pizza"
        >
          🍕
        </span>
      ))}
    </div>
  );
};

export default PizzaProgress; 