import { useState, useEffect } from 'react';
import { celebrities, convertToBitcoinPizza } from '../data/celebrities';
import PizzaProgress from './PizzaProgress';

const Quiz = () => {
  const [currentCelebrity, setCurrentCelebrity] = useState(null);
  const [randomValue, setRandomValue] = useState(0);
  const [score, setScore] = useState(0);
  const [btcPrice, setBtcPrice] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedback, setFeedback] = useState({ isCorrect: false, message: '' });
  const [actualValue, setActualValue] = useState(0);
  const [imageLoading, setImageLoading] = useState(true);
  const [imageError, setImageError] = useState(false);

  // Function to get current Bitcoin price
  useEffect(() => {
    const fetchBtcPrice = async () => {
      try {
        const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd');
        const data = await response.json();
        setBtcPrice(data.bitcoin.usd);
      } catch (error) {
        console.error('Error fetching BTC price:', error);
        setBtcPrice(50000);
      }
    };
    fetchBtcPrice();
  }, []);

  // Function to start a new question
  const startNewQuestion = () => {
    const randomCelebrity = celebrities[Math.floor(Math.random() * celebrities.length)];
    const randomBtcPizza = Math.floor(Math.random() * 20) + 1;
    setCurrentCelebrity(randomCelebrity);
    setRandomValue(randomBtcPizza);
    setShowFeedback(false);
    setImageLoading(true);
    setImageError(false);
  };

  // Function to handle answer
  const handleAnswer = (isGreater) => {
    const celebrityNetWorthInBtcPizza = convertToBitcoinPizza(currentCelebrity.netWorth, btcPrice);
    setActualValue(celebrityNetWorthInBtcPizza);
    
    const isCorrect = (isGreater && celebrityNetWorthInBtcPizza > randomValue) ||
                     (!isGreater && celebrityNetWorthInBtcPizza < randomValue);
    
    setFeedback({
      isCorrect,
      message: isCorrect 
        ? 'Correct Answer! 🎉' 
        : `Wrong Answer! ${currentCelebrity.name}'s net worth is ${celebrityNetWorthInBtcPizza.toFixed(2)} ₿ 🍕`
    });
    
    setShowFeedback(true);
    
    if (isCorrect) {
      setScore(prev => prev + 1);
      setTimeout(() => {
        startNewQuestion();
      }, 2000);
    } else {
      setTimeout(() => {
        setGameOver(true);
      }, 3000);
    }
  };

  // Start the game
  useEffect(() => {
    if (btcPrice > 0) {
      startNewQuestion();
    }
  }, [btcPrice]);

  console.log('Quiz rendering with score:', score); // Debug log

  // Calcolo il numero corrente di domanda (score + 1, perché parte da 0)
  const currentQuestion = score + 1;
  const totalQuestions = 8;

  if (gameOver) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
        <div className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full text-center">
          <h1 className="text-4xl font-bold mb-4">Game Over!</h1>
          <p className="text-2xl mb-4">Final Score: {score}</p>
          <button
            onClick={() => {
              setScore(0);
              setGameOver(false);
              startNewQuestion();
            }}
            style={{
              padding: '1.1rem 2.5rem',
              borderRadius: '999px',
              background: 'linear-gradient(135deg, #ffe082 0%, #ff9800 60%, #ffb300 100%)',
              color: '#fff',
              fontWeight: 'bold',
              fontSize: '1.25rem',
              boxShadow: '0 6px 32px 0 rgba(255,140,0,0.18), 0 0 0 4px #fff3e0 inset',
              border: 'none',
              outline: 'none',
              cursor: 'pointer',
              position: 'relative',
              transition: 'transform 0.15s, box-shadow 0.2s',
              textShadow: '0 2px 8px #ffecb3',
              marginTop: '1.5rem',
            }}
            onMouseDown={e => e.currentTarget.style.transform = 'scale(0.96)'}
            onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
            onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
          >
            Play Again
          </button>
        </div>
      </div>
    );
  }

  if (!currentCelebrity) {
    return <div>Loading...</div>;
  }

  return (
    <>
      {/* Pizza progress fisso in basso a destra */}
      <div style={{ position: 'fixed', bottom: 40, right: 40, zIndex: 1000 }}>
        <PizzaProgress score={score} totalSlices={8} currentQuestion={currentQuestion} totalQuestions={totalQuestions} />
      </div>
      {/* Container principale del quiz */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh' }}>
        <div className="bg-white/30 rounded-3xl max-w-xl w-full p-4 backdrop-blur-lg">
          <h1 className="text-4xl font-extrabold mb-8 text-center bg-gradient-to-r from-orange-400 via-yellow-300 to-orange-500 bg-clip-text text-transparent drop-shadow-lg tracking-tight">₿ 🍕 Quiz</h1>
          {/* Quiz principale */}
          <div>
            <div className="mb-10 relative" style={{ paddingBottom: '2.5rem' }}>
              <div
                style={{
                  background: 'rgba(255,255,255,0.85)',
                  borderRadius: '2rem',
                  boxShadow: '0 4px 24px 0 rgba(255,140,0,0.18)',
                  border: '2.5px solid #ffe0b2',
                  padding: '1.5rem',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  maxWidth: 380,
                  margin: '0 auto',
                  minHeight: 320,
                  position: 'relative',
                  overflow: 'hidden',
                }}
              >
                {imageLoading && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-orange-400"></div>
                  </div>
                )}
                {imageError ? (
                  <div className="text-center text-gray-500">
                    <p>Image not available</p>
                    <p className="text-sm">{currentCelebrity.name}</p>
                  </div>
                ) : (
                  <img 
                    src={currentCelebrity.image} 
                    alt={currentCelebrity.name}
                    className={`w-full h-full object-cover transition-opacity duration-300 ${imageLoading ? 'opacity-0' : 'opacity-100'} rounded-2xl shadow-lg`}
                    style={{ maxHeight: 320, maxWidth: 320, borderRadius: '1.5rem' }}
                    onLoad={() => setImageLoading(false)}
                    onError={() => {
                      setImageLoading(false);
                      setImageError(true);
                    }}
                  />
                )}
              </div>
              <h2 className="text-3xl font-extrabold text-center mt-6 text-orange-700 drop-shadow tracking-tight">{currentCelebrity.name}</h2>
            </div>

            {!showFeedback ? (
              <>
                <div className="text-center mb-10" style={{ paddingBottom: '2.5rem' }}>
                  <p className="text-xl font-semibold text-orange-900 drop-shadow-sm">
                    Is {currentCelebrity.name}'s net worth greater or less than {randomValue} ₿ 🍕?
                  </p>
                </div>

                <div style={{ display: 'flex', justifyContent: 'center', gap: '2rem', paddingBottom: '2.5rem' }}>
                  <button
                    onClick={() => handleAnswer(true)}
                    style={{
                      padding: '1.1rem 2.5rem',
                      borderRadius: '999px',
                      background: 'linear-gradient(135deg, #ffe082 0%, #ff9800 60%, #ffb300 100%)',
                      color: '#fff',
                      fontWeight: 'bold',
                      fontSize: '1.25rem',
                      boxShadow: '0 6px 32px 0 rgba(255,140,0,0.18), 0 0 0 4px #fff3e0 inset',
                      border: 'none',
                      outline: 'none',
                      cursor: 'pointer',
                      position: 'relative',
                      transition: 'transform 0.15s, box-shadow 0.2s',
                      textShadow: '0 2px 8px #ffecb3',
                    }}
                    onMouseDown={e => e.currentTarget.style.transform = 'scale(0.96)'}
                    onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
                    onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
                  >
                    Greater (+)
                  </button>
                  <button
                    onClick={() => handleAnswer(false)}
                    style={{
                      padding: '1.1rem 2.5rem',
                      borderRadius: '999px',
                      background: 'linear-gradient(135deg, #ff9800 0%, #ffe082 60%, #ffb300 100%)',
                      color: '#fff',
                      fontWeight: 'bold',
                      fontSize: '1.25rem',
                      boxShadow: '0 6px 32px 0 rgba(255,140,0,0.18), 0 0 0 4px #fff3e0 inset',
                      border: 'none',
                      outline: 'none',
                      cursor: 'pointer',
                      position: 'relative',
                      transition: 'transform 0.15s, box-shadow 0.2s',
                      textShadow: '0 2px 8px #ffecb3',
                    }}
                    onMouseDown={e => e.currentTarget.style.transform = 'scale(0.96)'}
                    onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
                    onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
                  >
                    Less (-)
                  </button>
                </div>
              </>
            ) : (
              <div
                style={{
                  display: 'inline-block',
                  margin: '2rem auto 0',
                  padding: '1.5rem 2.5rem',
                  borderRadius: '999px',
                  background: feedback.isCorrect
                    ? 'linear-gradient(135deg, #aee571 0%, #8bc34a 60%, #d4fc79 100%)'
                    : 'linear-gradient(135deg, #ffb199 0%, #ff0844 60%, #ffb199 100%)',
                  color: '#fff',
                  fontWeight: 'bold',
                  fontSize: '1.3rem',
                  boxShadow: '0 6px 32px 0 rgba(255,140,0,0.10), 0 0 0 4px #fff3e0 inset',
                  border: 'none',
                  outline: 'none',
                  textShadow: '0 2px 8px #fffde7',
                  transition: 'all 0.2s',
                  position: 'relative',
                  minWidth: '260px',
                  textAlign: 'center',
                }}
              >
                {feedback.message}
                {!feedback.isCorrect && (
                  <div style={{ fontSize: '1rem', fontWeight: 400, marginTop: '0.5rem', color: '#fffbe7', textShadow: '0 1px 4px #ffb300' }}>
                    {currentCelebrity.name}'s net worth is {actualValue.toFixed(2)} ₿ 🍕
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default Quiz; 