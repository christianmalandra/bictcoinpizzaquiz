// Import delle immagini locali
import elonMusk from '../assets/images/elon-musk.jpeg';
import jeffBezos from '../assets/images/jeff-bezos.jpeg';
import markZuckerberg from '../assets/images/mark-zuckerberg.jpeg';
import billGates from '../assets/images/bill-gates.jpeg';
import warrenBuffett from '../assets/images/warren-buffett.jpeg';
import kanyeWest from '../assets/images/kanye-west.jpeg';
import justinBieber from '../assets/images/justin-bieber.jpeg';
import taylorSwift from '../assets/images/taylor-swift.jpeg';
import rihanna from '../assets/images/rihanna.jpeg';
import jayZ from '../assets/images/jay-z.jpeg';
import leonardoDiCaprio from '../assets/images/leonardo-dicaprio.jpeg';

// Remove all image imports
export const celebrities = [
  // Tech & Business Billionaires
  {
    name: "Elon Musk",
    netWorth: 198000000000, // in USD (Forbes, Marzo 2024)
    image: elonMusk,
    source: "Forbes",
    lastUpdated: "Marzo 2024",
    category: "Tech"
  },
  {
    name: "Jeff Bezos",
    netWorth: 177000000000, // in USD (Forbes, Marzo 2024)
    image: jeffBezos,
    source: "Forbes",
    lastUpdated: "Marzo 2024",
    category: "Tech"
  },
  {
    name: "Mark Zuckerberg",
    netWorth: 177000000000, // in USD (Forbes, Marzo 2024)
    image: markZuckerberg,
    source: "Forbes",
    lastUpdated: "Marzo 2024",
    category: "Tech"
  },
  {
    name: "Bill Gates",
    netWorth: 128000000000, // in USD (Forbes, Marzo 2024)
    image: billGates,
    source: "Forbes",
    lastUpdated: "Marzo 2024",
    category: "Tech"
  },
  {
    name: "Warren Buffett",
    netWorth: 133000000000, // in USD (Forbes, Marzo 2024)
    image: warrenBuffett,
    source: "Forbes",
    lastUpdated: "Marzo 2024",
    category: "Business"
  },
  // Celebrities & Entertainment
  {
    name: "Kanye West",
    netWorth: 400000000, // in USD (Celebrity Net Worth, Marzo 2024)
    image: kanyeWest,
    source: "Celebrity Net Worth",
    lastUpdated: "Marzo 2024",
    category: "Entertainment"
  },
  {
    name: "Justin Bieber",
    netWorth: 300000000, // in USD (Celebrity Net Worth, Marzo 2024)
    image: justinBieber,
    source: "Celebrity Net Worth",
    lastUpdated: "Marzo 2024",
    category: "Entertainment"
  },
  {
    name: "Taylor Swift",
    netWorth: 1100000000, // in USD (Forbes, Marzo 2024)
    image: taylorSwift,
    source: "Forbes",
    lastUpdated: "Marzo 2024",
    category: "Entertainment"
  },
  {
    name: "Rihanna",
    netWorth: 1400000000, // in USD (Forbes, Marzo 2024)
    image: rihanna,
    source: "Forbes",
    lastUpdated: "Marzo 2024",
    category: "Entertainment"
  },
  {
    name: "Jay-Z",
    netWorth: 2500000000, // in USD (Forbes, Marzo 2024)
    image: jayZ,
    source: "Forbes",
    lastUpdated: "Marzo 2024",
    category: "Entertainment"
  },
  {
    name: "Leonardo DiCaprio",
    netWorth: 300000000, // in USD (Celebrity Net Worth, Marzo 2024)
    image: leonardoDiCaprio,
    source: "Celebrity Net Worth",
    lastUpdated: "Marzo 2024",
    category: "Entertainment"
  }
];

// Costante per la conversione: 1 ₿ 🍕 = 5000 BTC
export const BITCOIN_PIZZA_RATIO = 5000;

// Funzione per convertire USD in ₿ 🍕
export const convertToBitcoinPizza = (usdAmount, btcPrice) => {
  return (usdAmount / btcPrice) / BITCOIN_PIZZA_RATIO;
}; 